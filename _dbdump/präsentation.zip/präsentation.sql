-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server Version:               8.0.17 - MySQL Community Server - GPL
-- Server Betriebssystem:        Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Exportiere Datenbank Struktur für massedterm
CREATE DATABASE IF NOT EXISTS `massedterm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `massedterm`;

-- Exportiere Struktur von Tabelle massedterm.authorities
CREATE TABLE IF NOT EXISTS `authorities` (
  `username` varchar(128) NOT NULL,
  `authority` varchar(128) NOT NULL,
  UNIQUE KEY `AUTHORITIES_UNIQUE` (`username`,`authority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Exportiere Daten aus Tabelle massedterm.authorities: ~2 rows (ungefähr)
/*!40000 ALTER TABLE `authorities` DISABLE KEYS */;
INSERT INTO `authorities` (`username`, `authority`) VALUES
	('admin', 'ROLE_ADMIN'),
	('user', 'ROLE_USER');
/*!40000 ALTER TABLE `authorities` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle massedterm.cards
CREATE TABLE IF NOT EXISTS `cards` (
  `cardid` int(11) NOT NULL AUTO_INCREMENT,
  `stackid` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `isCorrect` tinyint(1) NOT NULL DEFAULT '0',
  `wrongness` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cardid`),
  KEY `stackid` (`stackid`),
  CONSTRAINT `cards_ibfk_1` FOREIGN KEY (`stackid`) REFERENCES `stacks` (`stackid`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Exportiere Daten aus Tabelle massedterm.cards: ~36 rows (ungefähr)
/*!40000 ALTER TABLE `cards` DISABLE KEYS */;
INSERT INTO `cards` (`cardid`, `stackid`, `question`, `answer`, `isCorrect`, `wrongness`) VALUES
	(1, 1, 'test1', 'tese2', 0, 1),
	(2, 1, 'test', 'test', 0, 1),
	(3, 1, 'test', 'df', 0, 1),
	(4, 1, 'lul', 'ko', 0, 1),
	(5, 5, '<p>Linux</p>', '<p>Ein Betriebssysteme</p>', 0, 1),
	(6, 5, '<p>Windows</p>', '<p>Auch ein Betriebssystem</p>', 0, 1),
	(7, 6, '<p>Wie gehts dir?</p>', '<p>Gut</p>', 0, 1),
	(8, 5, '<p>Kjihf</p>', '<p>naskndkj</p>', 0, 1),
	(9, 5, '<p>asdh</p>', '<p>nasjk</p>', 0, 1),
	(10, 7, '<p>LOL</p>', '<p>ju</p>', 0, 1),
	(13, 8, '<h1><strong>Hier würde die Frage stehen...</strong></h1>', '<h1>...und hier würde die Antwort stehen.</h1>', 0, 1),
	(14, 8, '<p><strong>Wie ist eine Variable aufgebaut?</strong></p>', '<p><span style="color: rgb(33, 32, 28);">&lt;TYP&gt;&nbsp;&lt;BEZEICHNER&gt; = &lt;WERT&gt;</span></p>', 0, 1),
	(15, 8, '<h1>Wie sind wir auf die Idee gekommen?</h1>', '<h1>Durch die Sabrina, die es als Spaß gemeint hat.</h1>', 0, 1),
	(16, 8, '<p>Was waren unsere Ziele?</p>', '<p>Ein funktionierendes Karteikarten Programm das man selber verwenden kann.</p>', 0, 1),
	(17, 8, '<p>Weitere Ziele?</p>', '<p>So viele unterschiedlichen Techniken verwenden um uns für die weiteren Semester vorzubereiten.</p>', 0, 1),
	(18, 8, '<p>Weitere Ziele?</p>', '<p>Als Team eine geeignete Strategie zu finden um voneinander lernen zu können und um uns gegenseitig zu unterstützen.</p>', 0, 1),
	(20, 8, '<p>Eine falsche Antwort :(</p>', '<p>Wird in der nächsten Runde wiederholt bis man sie richtig hat!</p>', 0, 1),
	(21, 8, '<p>Die Richtige Antwort..</p>', '<p>Wird sofort abgespeichert! :)</p>', 0, 1),
	(41, 62, '<p>Deadlock</p>', '<p>Prozesse warten auf eine Resource welche von einem anderen Prozess besetzt wird.</p><p>Voraussetzungen:</p><ul><li>Mutual exclusion</li><li>hold and wait</li><li>non preemptable</li><li>circular wait condition</li></ul>', 0, 1),
	(42, 62, '<p>Unsafe state</p>', '<p>multiple processes could end up in a Deadlock but theiy are no (yet) currently</p>', 0, 1),
	(43, 62, '<p>Process</p>', '<p>program in execution</p>', 0, 1),
	(44, 65, '<p>Frage</p>', '<p>Antwort</p>', 0, 1),
	(60, 66, '<p>Warum Webapplikation?</p>', '<ul><li>Desktop</li><li>Mobile</li></ul>', 0, 1),
	(61, 66, '<p>Was sind die technischen Aspekte?</p>', '<ul><li>Webapplikation</li><li>Spring</li><li>Java Server</li><li>JS/HTML/CSS Client</li></ul>', 0, 1),
	(62, 66, '<p>Was ist Spring?</p>', '<ul><li>Webframework</li><li>Funktionalitäten um <strong>URL\'s</strong> mit <strong>Logik </strong>und <strong>Templates</strong> zu verbinden</li></ul>', 0, 1),
	(63, 66, '<p>Warum Spring?</p>', '<ul><li>Gibt <strong>Struktur </strong>für Code vor (MVC)</li><li>Einfacher Einstieg</li><li>Viele "<strong>Libraries</strong>" (Datenbank)</li></ul>', 0, 1),
	(64, 66, '<p>Daten Geräte-übergreifend verfügbar machen. Aber wie ? <span style="color: rgb(51, 51, 51);">🤔</span></p>', '<ul><li>Datenbank</li><li>Mysql</li></ul>', 0, 1),
	(65, 67, '<p>Lol</p>', '<p>Hin</p>', 0, 1),
	(66, 2, '<p><br></p>', '<p><br></p>', 0, 1),
	(67, 68, '<p>M</p><p>A</p><p>S</p><p>S</p><p>E</p><p>D</p><p><br></p><p>Term</p>', '<p>Manuela</p><p>Alexander</p><p>Sabrina</p><p>Stefanie</p><p>Emanuel</p><p>Dennis</p><p><br></p><p>Term</p>', 0, 1),
	(71, 69, '<p>Was lief gut?</p>', '<ul><li>gute Kommunikation</li><li>Interesse war von Anfang da</li><li>jedes Mitglied war im Projekt beteiligt</li></ul>', 0, 1),
	(72, 69, '<p>Was lief schlecht?</p>', '<ul><li>Team Mitglied - erkrankt</li><li>Team Mitglied - FH abgebrochen</li><li>weniger Zeit als erwartet </li></ul>', 0, 1),
	(74, 71, '<p>Wer ist das im Hintergrund?</p>', '<p>Appa</p>', 0, 1),
	(75, 68, '<p>Verwendete Tools</p>', '<ul><li>Trello -	Projektmanagement</li><li>Git - Versionierung</li><li>Adobe XD	-	Design</li><li>Visio -	Diagramme</li><li>Discord -	Kommunikation</li><li>OneDrive -	Dateimanagement</li></ul>', 0, 1),
	(76, 73, '<p>TEST 1</p>', '<p>test <strong>2</strong></p>', 0, 1),
	(77, 73, '<p>ko</p>', '<p>dsfhud</p>', 0, 1);
/*!40000 ALTER TABLE `cards` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle massedterm.responses
CREATE TABLE IF NOT EXISTS `responses` (
  `responseid` int(11) NOT NULL AUTO_INCREMENT,
  `roundid` int(11) NOT NULL,
  `cardid` int(11) NOT NULL,
  `isCorrect` tinyint(1) NOT NULL DEFAULT '0',
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `USER` varchar(255) NOT NULL,
  PRIMARY KEY (`responseid`),
  KEY `roundid` (`roundid`),
  KEY `cardid` (`cardid`),
  CONSTRAINT `cards_obfk_1` FOREIGN KEY (`cardid`) REFERENCES `cards` (`cardid`),
  CONSTRAINT `responses_ibfk_1` FOREIGN KEY (`roundid`) REFERENCES `rounds` (`roundid`)
) ENGINE=InnoDB AUTO_INCREMENT=527 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Exportiere Daten aus Tabelle massedterm.responses: ~113 rows (ungefähr)
/*!40000 ALTER TABLE `responses` DISABLE KEYS */;
INSERT INTO `responses` (`responseid`, `roundid`, `cardid`, `isCorrect`, `timestamp`, `USER`) VALUES
	(413, 54, 41, 1, '2020-01-13 21:04:21', 'admin'),
	(414, 55, 41, 0, '2020-01-13 21:12:41', 'admin'),
	(415, 55, 42, 0, '2020-01-13 21:12:41', 'admin'),
	(416, 55, 43, 0, '2020-01-13 21:12:41', 'admin'),
	(417, 55, 41, 1, '2020-01-13 21:12:42', 'admin'),
	(418, 55, 42, 1, '2020-01-13 21:12:42', 'admin'),
	(419, 55, 43, 1, '2020-01-13 21:12:43', 'admin'),
	(420, 55, 41, 0, '2020-01-13 21:13:26', 'admin'),
	(421, 55, 42, 1, '2020-01-13 21:13:27', 'admin'),
	(422, 55, 43, 1, '2020-01-13 21:13:28', 'admin'),
	(423, 55, 41, 1, '2020-01-13 21:13:29', 'admin'),
	(424, 55, 41, 1, '2020-01-13 21:13:29', 'admin'),
	(425, 57, 44, 1, '2020-01-13 21:25:01', 'admin'),
	(426, 58, 44, 0, '2020-01-13 21:26:53', 'admin'),
	(427, 58, 44, 1, '2020-01-13 21:27:08', 'admin'),
	(428, 58, 44, 1, '2020-01-13 21:27:31', 'admin'),
	(429, 56, 41, 1, '2020-01-13 21:43:04', 'admin'),
	(430, 56, 42, 1, '2020-01-13 21:43:11', 'admin'),
	(431, 56, 43, 0, '2020-01-13 21:43:54', 'admin'),
	(432, 56, 43, 1, '2020-01-13 21:43:56', 'admin'),
	(433, 56, 43, 1, '2020-01-13 21:43:58', 'admin'),
	(434, 60, 41, 0, '2020-01-13 21:44:02', 'admin'),
	(435, 60, 42, 1, '2020-01-13 21:44:02', 'admin'),
	(436, 60, 43, 0, '2020-01-13 21:44:04', 'admin'),
	(437, 60, 41, 1, '2020-01-13 21:44:05', 'admin'),
	(438, 60, 43, 1, '2020-01-13 21:44:06', 'admin'),
	(439, 60, 41, 1, '2020-01-13 21:44:06', 'admin'),
	(440, 60, 43, 1, '2020-01-13 21:44:07', 'admin'),
	(441, 62, 60, 1, '2020-01-20 13:50:35', 'admin'),
	(442, 62, 61, 1, '2020-01-20 13:51:14', 'admin'),
	(443, 62, 62, 1, '2020-01-20 13:52:40', 'admin'),
	(444, 62, 63, 1, '2020-01-20 13:54:29', 'admin'),
	(445, 62, 64, 1, '2020-01-20 13:56:20', 'admin'),
	(446, 63, 60, 1, '2020-01-20 15:36:09', 'admin'),
	(447, 63, 61, 1, '2020-01-20 15:36:19', 'admin'),
	(448, 63, 62, 1, '2020-01-20 15:36:25', 'admin'),
	(449, 63, 63, 1, '2020-01-20 15:36:31', 'admin'),
	(450, 63, 64, 1, '2020-01-20 15:36:43', 'admin'),
	(451, 64, 60, 1, '2020-01-21 11:30:26', 'admin'),
	(452, 64, 61, 1, '2020-01-21 11:30:41', 'admin'),
	(453, 64, 62, 1, '2020-01-21 11:31:05', 'admin'),
	(454, 64, 63, 1, '2020-01-21 11:31:25', 'admin'),
	(455, 64, 64, 1, '2020-01-21 11:42:44', 'admin'),
	(456, 66, 60, 1, '2020-01-21 11:43:36', 'admin'),
	(457, 66, 61, 1, '2020-01-21 11:44:07', 'admin'),
	(458, 66, 62, 1, '2020-01-21 11:46:59', 'admin'),
	(459, 66, 63, 1, '2020-01-21 11:47:02', 'admin'),
	(460, 66, 64, 1, '2020-01-21 11:47:28', 'admin'),
	(461, 67, 60, 1, '2020-01-21 11:47:58', 'admin'),
	(462, 67, 61, 0, '2020-01-21 11:48:01', 'admin'),
	(463, 67, 61, 1, '2020-01-21 11:53:49', 'admin'),
	(464, 67, 62, 1, '2020-01-21 11:53:51', 'admin'),
	(465, 67, 61, 1, '2020-01-21 11:54:44', 'admin'),
	(466, 67, 63, 0, '2020-01-21 11:58:30', 'admin'),
	(467, 67, 64, 0, '2020-01-21 11:58:33', 'admin'),
	(468, 67, 63, 1, '2020-01-21 12:12:14', 'admin'),
	(469, 67, 64, 0, '2020-01-21 12:12:15', 'admin'),
	(470, 65, 65, 1, '2020-01-21 12:12:23', 'admin'),
	(471, 67, 64, 1, '2020-01-21 12:15:19', 'admin'),
	(472, 67, 63, 1, '2020-01-21 12:20:49', 'admin'),
	(473, 67, 64, 1, '2020-01-21 12:20:50', 'admin'),
	(474, 69, 60, 1, '2020-01-21 12:22:26', 'admin'),
	(475, 69, 61, 1, '2020-01-21 12:29:33', 'admin'),
	(476, 69, 62, 0, '2020-01-21 12:32:24', 'admin'),
	(477, 69, 63, 0, '2020-01-21 12:32:24', 'admin'),
	(478, 69, 62, 1, '2020-01-21 12:32:26', 'admin'),
	(479, 69, 64, 1, '2020-01-21 12:32:26', 'admin'),
	(480, 69, 63, 1, '2020-01-21 12:32:27', 'admin'),
	(481, 69, 62, 1, '2020-01-21 12:32:27', 'admin'),
	(482, 69, 63, 1, '2020-01-21 12:32:29', 'admin'),
	(483, 70, 60, 1, '2020-01-21 12:36:08', 'admin'),
	(484, 70, 61, 1, '2020-01-21 12:37:56', 'admin'),
	(486, 70, 62, 1, '2020-01-21 15:41:18', 'admin'),
	(487, 70, 63, 1, '2020-01-21 15:41:19', 'admin'),
	(488, 70, 64, 1, '2020-01-21 15:41:19', 'admin'),
	(489, 73, 60, 1, '2020-01-21 15:42:33', 'admin'),
	(490, 73, 61, 1, '2020-01-21 15:43:32', 'admin'),
	(491, 73, 62, 1, '2020-01-21 15:44:28', 'admin'),
	(492, 73, 63, 1, '2020-01-21 15:45:48', 'admin'),
	(493, 73, 64, 1, '2020-01-21 15:48:21', 'admin'),
	(494, 74, 60, 1, '2020-01-21 15:50:19', 'admin'),
	(495, 74, 61, 1, '2020-01-21 15:51:24', 'admin'),
	(496, 74, 62, 1, '2020-01-21 15:52:52', 'admin'),
	(497, 74, 63, 1, '2020-01-21 15:54:12', 'admin'),
	(498, 74, 64, 1, '2020-01-21 15:55:36', 'admin'),
	(499, 76, 13, 1, '2020-01-21 16:17:46', 'admin'),
	(500, 76, 15, 1, '2020-01-21 16:25:09', 'admin'),
	(501, 76, 14, 1, '2020-01-22 13:56:36', 'admin'),
	(502, 76, 16, 1, '2020-01-22 13:56:37', 'admin'),
	(503, 76, 17, 1, '2020-01-22 13:56:37', 'admin'),
	(504, 76, 18, 1, '2020-01-22 13:56:37', 'admin'),
	(505, 76, 20, 1, '2020-01-22 13:56:37', 'admin'),
	(506, 76, 21, 1, '2020-01-22 13:56:38', 'admin'),
	(507, 79, 67, 1, '2020-01-22 14:09:03', 'admin'),
	(508, 79, 75, 1, '2020-01-22 14:10:36', 'admin'),
	(509, 78, 13, 1, '2020-01-22 14:11:30', 'admin'),
	(510, 78, 14, 1, '2020-01-22 14:11:43', 'admin'),
	(511, 78, 15, 1, '2020-01-22 14:12:20', 'admin'),
	(512, 78, 16, 1, '2020-01-22 14:12:34', 'admin'),
	(513, 78, 17, 1, '2020-01-22 14:12:51', 'admin'),
	(514, 78, 18, 1, '2020-01-22 14:13:11', 'admin'),
	(515, 78, 20, 0, '2020-01-22 14:13:25', 'admin'),
	(516, 78, 21, 1, '2020-01-22 14:13:32', 'admin'),
	(517, 78, 20, 1, '2020-01-22 14:13:52', 'admin'),
	(518, 78, 20, 1, '2020-01-22 14:14:00', 'admin'),
	(519, 75, 60, 1, '2020-01-22 14:18:13', 'admin'),
	(520, 75, 61, 1, '2020-01-22 14:19:29', 'admin'),
	(521, 75, 62, 1, '2020-01-22 14:20:04', 'admin'),
	(522, 75, 63, 1, '2020-01-22 14:20:51', 'admin'),
	(523, 75, 64, 1, '2020-01-22 14:21:19', 'admin'),
	(524, 80, 71, 1, '2020-01-22 14:25:03', 'admin'),
	(525, 80, 72, 1, '2020-01-22 14:25:34', 'admin'),
	(526, 81, 67, 1, '2020-01-22 14:44:46', 'admin');
/*!40000 ALTER TABLE `responses` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle massedterm.rounds
CREATE TABLE IF NOT EXISTS `rounds` (
  `roundid` int(11) NOT NULL AUTO_INCREMENT,
  `stackid` int(11) NOT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `USER` varchar(255) NOT NULL,
  PRIMARY KEY (`roundid`),
  KEY `stackid` (`stackid`),
  CONSTRAINT `rounds_ibfk_1` FOREIGN KEY (`stackid`) REFERENCES `stacks` (`stackid`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Exportiere Daten aus Tabelle massedterm.rounds: ~32 rows (ungefähr)
/*!40000 ALTER TABLE `rounds` DISABLE KEYS */;
INSERT INTO `rounds` (`roundid`, `stackid`, `timestamp`, `USER`) VALUES
	(54, 62, '2020-01-13 21:03:50', 'admin'),
	(55, 62, '2020-01-13 21:04:22', 'admin'),
	(56, 62, '2020-01-13 21:13:31', 'admin'),
	(57, 65, '2020-01-13 21:24:34', 'admin'),
	(58, 65, '2020-01-13 21:25:03', 'admin'),
	(59, 65, '2020-01-13 21:27:40', 'admin'),
	(60, 62, '2020-01-13 21:44:00', 'admin'),
	(61, 62, '2020-01-13 21:44:08', 'admin'),
	(62, 66, '2020-01-20 13:41:47', 'admin'),
	(63, 66, '2020-01-20 13:56:21', 'admin'),
	(64, 66, '2020-01-20 15:36:45', 'admin'),
	(65, 67, '2020-01-21 11:42:31', 'admin'),
	(66, 66, '2020-01-21 11:42:46', 'admin'),
	(67, 66, '2020-01-21 11:47:29', 'admin'),
	(68, 67, '2020-01-21 12:12:24', 'admin'),
	(69, 66, '2020-01-21 12:20:51', 'admin'),
	(70, 66, '2020-01-21 12:32:30', 'admin'),
	(71, 70, '2020-01-21 13:36:01', 'admin'),
	(72, 70, '2020-01-21 13:36:04', 'admin'),
	(73, 66, '2020-01-21 15:41:21', 'admin'),
	(74, 66, '2020-01-21 15:48:25', 'admin'),
	(75, 66, '2020-01-21 15:55:38', 'admin'),
	(76, 8, '2020-01-21 16:05:58', 'admin'),
	(77, 71, '2020-01-21 16:12:22', 'user'),
	(78, 8, '2020-01-22 13:56:39', 'admin'),
	(79, 68, '2020-01-22 13:56:58', 'admin'),
	(80, 69, '2020-01-22 13:57:16', 'admin'),
	(81, 68, '2020-01-22 14:10:39', 'admin'),
	(82, 8, '2020-01-22 14:14:06', 'admin'),
	(83, 73, '2020-01-22 14:17:36', 'admin'),
	(84, 66, '2020-01-22 14:23:46', 'admin'),
	(85, 69, '2020-01-22 14:25:36', 'admin');
/*!40000 ALTER TABLE `rounds` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle massedterm.stacks
CREATE TABLE IF NOT EXISTS `stacks` (
  `stackid` int(11) NOT NULL AUTO_INCREMENT,
  `stackname` varchar(255) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `USER` varchar(255) NOT NULL,
  PRIMARY KEY (`stackid`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Exportiere Daten aus Tabelle massedterm.stacks: ~20 rows (ungefähr)
/*!40000 ALTER TABLE `stacks` DISABLE KEYS */;
INSERT INTO `stacks` (`stackid`, `stackname`, `deleted`, `USER`) VALUES
	(1, 'lol', 1, 'admin'),
	(2, 'test', 1, 'admin'),
	(3, 'dsf', 1, 'admin'),
	(4, 'df', 1, 'admin'),
	(5, 'Betriebssysteme', 1, 'admin'),
	(6, 'Poookuju', 1, 'admin'),
	(7, 'KLO', 1, 'admin'),
	(8, 'Aller Anfang ist schwer', 0, 'admin'),
	(62, 'Betriebssysteme', 1, 'admin'),
	(63, 'Haram', 1, 'admin'),
	(64, 'Teamarbeit', 1, 'admin'),
	(65, 'Programmierung', 1, 'admin'),
	(66, 'Technische Aspekte', 0, 'admin'),
	(67, 'Ziele', 1, 'admin'),
	(68, 'Vorstellung', 0, 'admin'),
	(69, 'Reflexion', 0, 'admin'),
	(70, 'Bier', 1, 'admin'),
	(71, 'Hey Leute 🍺', 0, 'user'),
	(72, 'Beispiel1', 1, 'admin'),
	(73, 'Beispiel', 0, 'admin');
/*!40000 ALTER TABLE `stacks` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle massedterm.users
CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `enabled` char(1) NOT NULL,
  PRIMARY KEY (`username`),
  CONSTRAINT `users_chk_1` CHECK ((`ENABLED` in (_utf8mb4'Y',_utf8mb4'N')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Exportiere Daten aus Tabelle massedterm.users: ~2 rows (ungefähr)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`username`, `password`, `enabled`) VALUES
	('admin', 'pass', 'Y'),
	('user', 'user', 'Y');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
